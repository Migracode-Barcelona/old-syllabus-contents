# HTML & CSS

| Weeks                          | Content                                                                        |
| ------------------------------ | ------------------------------------------------------------------------------ |
| [week-01](./week-01/lesson.md) | Semantic HTML tags . Linking Resources . CSS Selectors . CSS Properties . Box model . Git Branching |
| [week-02](./week-02/lesson.md) | Responsive web design . Media queries . Flexbox (Content Layouts) . Git Merging              |
| [week-03](./week-03/lesson.md) | HTML Forms, Fields, Labels and Buttons . More Field Types . Accessibility . Fieldsets . Form Attributes . Git Merge Conflicts                    |
