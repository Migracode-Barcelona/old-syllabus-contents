# Homework

1. (Est. 1-2 hours) Complete Lesson 1 of this course on [Building High Conversion Web Forms](https://eu.udacity.com/course/building-high-conversion-web-forms--ud890).
1. (Est. 1-2  hours) Complete videos 1-16 in Lesson 2 of the same course as above. You can stop after lesson 17.
1. Revise what you've learned during the HTML/CSS module. Next week we'll have a short quiz for you.

# Prepare for the next class

Next week, we will begin learning and programming JavaScript. To prepare for the next lesson, watch a two minute video, ['What is JavaScript?'](https://www.youtube.com/watch?v=nItSSTwBvSU).
